package org.acme.infra;

import jakarta.persistence.EntityNotFoundException;
import org.acme.dtos.ExceptionDTO;
import jakarta.persistence.PersistenceException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;

@Provider
public class ControllerExceptionHandler implements ExceptionMapper<Exception>
{
    @Override
    public Response toResponse(Exception exception)
    {
        if (exception instanceof PersistenceException)
        {
            return handlePersistenceException((PersistenceException) exception);
        }
        else if (exception instanceof EntityNotFoundException)
        {
            return handleEntityNotFound();
        }
        else
        {
            return handleGeneralException(exception);
        }
    }

    private Response handlePersistenceException(PersistenceException exception)
    {
        // Aqui você pode tratar as violações de integridade, como violação de chave única
        ExceptionDTO exceptionDTO = new ExceptionDTO("Usuário já cadastrado", "400");
        return Response.status(Response.Status.BAD_REQUEST).entity(exceptionDTO).build();
    }

    private Response handleEntityNotFound()
    {
        return Response.status(Response.Status.NOT_FOUND).build();
    }

    private Response handleGeneralException(Exception exception)
    {
        ExceptionDTO exceptionDTO = new ExceptionDTO(exception.getMessage(), "500");
        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(exceptionDTO).build();
    }
}