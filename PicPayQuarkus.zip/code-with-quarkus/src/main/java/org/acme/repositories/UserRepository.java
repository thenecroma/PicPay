package org.acme.repositories;

import io.quarkus.hibernate.orm.panache.PanacheRepository;
import jakarta.enterprise.context.ApplicationScoped;
import org.acme.domain.user.User;
import java.util.Optional;

@ApplicationScoped
public class UserRepository implements PanacheRepository<User>
{
    // O PanacheRepository já oferece métodos como findAll(), persist(), etc.
    public Optional<User> findUserById(Long id)
    {
        return findByIdOptional(id);
    }

    public Optional<User> findUserByDocument(String document)
    {
        return find("document", document).firstResultOptional();
    }
}