package org.acme.domain.user;

public enum UserType
{
    COMMON,
    MERCHANT
}
