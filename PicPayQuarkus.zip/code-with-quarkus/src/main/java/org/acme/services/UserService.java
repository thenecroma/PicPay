package org.acme.services;

import org.acme.domain.user.User;
import org.acme.domain.user.UserType;
import org.acme.dtos.UserDTO;
import org.acme.repositories.UserRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.math.BigDecimal;
import java.util.List;

@ApplicationScoped
public class UserService
{

    @Inject
    private UserRepository repository;

    // Valida transação
    public void validateTransaction(User sender, BigDecimal amount) throws Exception
    {
        // Verifica se for Lojista, se for bloqueia transação
        if (sender.getUserType() == UserType.MERCHANT)
        {
            throw new Exception("Usuários LOJISTAS(MERCHANT) não podem realizar essa operação!");
        }

        // Verifica se usuário tem saldo para realizar transação
        if (sender.getBalance().compareTo(amount) < 0)
        {
            throw new Exception("Saldo insuficiente para transação!");
        }
    }

    // Encontra usuário
    public User findUserById(Long id) throws Exception
    {
        return this.repository.findByIdOptional(id)
                .orElseThrow(() -> new Exception("Usuário não encontrado!"));
    }

    // Salva registro de usuário
    public void saveUser(User user)
    {
        this.repository.persist(user);
    }

    // Cria usuário
    public User createUser(UserDTO data)
    {
        User newUser = new User(data);
        this.saveUser(newUser);
        return newUser;
    }

    public List<User> getAllUsers()
    {
        return this.repository.listAll();
    }
}