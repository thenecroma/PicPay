package org.acme.services;

import org.acme.domain.user.User;
import org.acme.dtos.NotificationDTO;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class NotificationService {

    public void sendNotification(User user, String message) throws Exception
    {
        String email = user.getEmail();
        NotificationDTO notificationRequest = new NotificationDTO(email, message);

        // Cria o Client usando o ClientBuilder
        Client client = ClientBuilder.newClient();

        // Define o endpoint da API externa
        WebTarget target = client.target("https://util.devi.tools/api/v1/notify");

        // Envia a solicitação
        Response notificationResponse = target.request(MediaType.APPLICATION_JSON)
                .post(Entity.entity(notificationRequest, MediaType.APPLICATION_JSON));

        // Verifica o status da resposta
        /*if (notificationResponse.getStatus() != Response.Status.OK.getStatusCode())
        {
            System.out.println("Não foi possível enviar notificação!");
            throw new Exception("Esse serviço encontra-se indisponível!");
        }*/

        System.out.println("Notificação enviada!");

        // Fecha o client para liberar recursos
        client.close();
    }
}