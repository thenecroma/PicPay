package org.acme.services;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.acme.domain.transaction.Transaction;
import org.acme.domain.user.User;
import org.acme.dtos.TransactionDTO;
import org.acme.repositories.TransactionRepository;
import org.acme.services.UserService;
import org.acme.services.NotificationService;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@ApplicationScoped
public class TransactionService
{
    @Inject
    private UserService userService;

    @Inject
    private TransactionRepository transactionRepository;

    @Inject
    private NotificationService notificationService;

    public Transaction createTransaction(TransactionDTO transaction) throws Exception
    {
        User sender = this.userService.findUserById(transaction.senderId());
        User receiver = this.userService.findUserById(transaction.receiverId());

        userService.validateTransaction(sender, transaction.value());

        boolean isAuthorized = this.autorizeTransaction(sender, transaction.value());

        if (!isAuthorized)
        {
            throw new Exception("Transação recusada!");
        }

        // Nome "newTransaction" para não usar o mesmo "transaction" do TransactionDTO
        Transaction newTransaction = new Transaction();
        newTransaction.setAmount(transaction.value());
        newTransaction.setSender(sender);
        newTransaction.setReceiver(receiver);
        newTransaction.setTimestamp(LocalDateTime.now());

        // Tira do sender e manda pro receiver (pagador e recebedor)
        sender.setBalance(sender.getBalance().subtract(transaction.value()));
        receiver.setBalance(receiver.getBalance().add(transaction.value()));

        // Agora você usa o método persist() de PanacheRepository para salvar a transação
        transactionRepository.persist(newTransaction);
        userService.saveUser(sender);
        userService.saveUser(receiver);

        this.notificationService.sendNotification(sender, "Transação realizada!");
        this.notificationService.sendNotification(receiver, "Transação recebida!");

        return newTransaction;
    }

    public boolean autorizeTransaction(User sender, BigDecimal amount)
    {
        // Lógica para autorizar a transação
        return true;
    }
}