package org.acme.controllers;

import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.acme.dtos.UserDTO;
import org.acme.services.UserService;
import org.acme.domain.user.User;

import java.util.List;

@Path("/users")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class UserController {

    @Inject
    UserService userService;

    @POST
    @Transactional
    public Response createUser(UserDTO user)
    {
        User newUser = userService.createUser(user);
        return Response.status(Response.Status.CREATED).entity(newUser).build();
    }

    @GET
    public Response getAllUsers()
    {
        List<User> users = userService.getAllUsers();
        return Response.ok(users).build();
    }
}