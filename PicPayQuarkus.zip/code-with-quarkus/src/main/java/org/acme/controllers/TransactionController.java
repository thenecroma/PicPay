package org.acme.controllers;

import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;

import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.acme.domain.transaction.Transaction;
import org.acme.dtos.TransactionDTO;
import org.acme.services.TransactionService;

@Path("/transactions")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)

public class TransactionController
{
    @Inject
    private TransactionService transactionService;

    @POST
    @Transactional
    public Response createTransaction(TransactionDTO transaction) {
        try {
            Transaction newTransaction = transactionService.createTransaction(transaction);
            return Response.ok(newTransaction).build();
        } catch (Exception e) {
            return Response.status(Response.Status.BAD_REQUEST).entity("Erro ao criar transação: " + e.getMessage()).build();
        }
    }

    /*public ResponseEntity<Transaction> createTransaction(@RequestBody TransactionDTO transaction) throws Exception
    {
        Transaction newTransaction = this.transactionService.createTransaction(transaction);
        return new ResponseEntity<>(newTransaction, HttpStatus.OK);
    }*/

}