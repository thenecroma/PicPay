package org.acme.dtos;

public record ExceptionDTO(String message, String statusCode)
{
}
