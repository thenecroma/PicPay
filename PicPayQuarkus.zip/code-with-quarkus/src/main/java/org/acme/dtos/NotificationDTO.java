package org.acme.dtos;

public record NotificationDTO(String email, String message)
{
}
